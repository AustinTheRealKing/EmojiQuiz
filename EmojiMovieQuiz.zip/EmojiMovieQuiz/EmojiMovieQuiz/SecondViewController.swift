//
//  SecondViewController.swift
//  EmojiMovieQuiz
//
//  Created by King, Austin on 2/9/20.
//  Copyright © 2020 King, Austin. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

